function collectOddsAndEvens() {
  // add whatever parameters you deem necessary - good luck!
}


