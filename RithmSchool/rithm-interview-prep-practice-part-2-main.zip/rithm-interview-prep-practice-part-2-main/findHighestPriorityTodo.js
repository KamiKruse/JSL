function findHighestPriorityTodo(todos) {
  // add whatever parameters you deem necessary - good luck!
}
