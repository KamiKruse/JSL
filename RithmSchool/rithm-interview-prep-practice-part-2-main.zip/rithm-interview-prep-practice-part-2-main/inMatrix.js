function inMatrix() {
 // add whatever parameters you deem necessary - good luck!
}

