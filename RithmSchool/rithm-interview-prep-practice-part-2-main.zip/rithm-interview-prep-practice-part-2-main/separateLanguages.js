function separateLanguages() {
  // add whatever parameters you deem necessary - good luck!
}

