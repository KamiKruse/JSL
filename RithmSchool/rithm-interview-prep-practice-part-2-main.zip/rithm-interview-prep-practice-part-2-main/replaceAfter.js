function replaceAfter() {
  // add whatever parameters you deem necessary - good luck!
}
