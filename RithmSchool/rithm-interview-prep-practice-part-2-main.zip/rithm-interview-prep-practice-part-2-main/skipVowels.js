function skipVowels() {
  // add whatever parameters you deem necessary - good luck!
}
