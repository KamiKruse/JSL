function robotInstructions() {
 // add whatever parameters you deem necessary - good luck!
}

