// add whatever parameters you deem necessary - good luck!
function countValues(){

}