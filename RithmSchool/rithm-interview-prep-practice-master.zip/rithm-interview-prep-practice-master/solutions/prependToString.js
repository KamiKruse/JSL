function prependToString(str1, str2) {
  return str2 + str1;
}