function charAt(str, idx) {
  // one-line solution using a ternary operator (condensed if/else)
  return idx < str.length ? str[idx] : '';
}